<!-- resources/views/admin/dayra/user_limit_details.blade.php -->

<div class="container-fluid mt-5">
    <div class="table-responsive">
        <table class="table table-striped">
            <tbody id="userData">
                @foreach ($data as $key => $value)
                    @if (is_array($value))
                        @foreach ($value as $nestedKey => $nestedValue)
                            <tr>
                                <td class="key-cell">{{ $nestedKey }}</td>
                                <td class="value-cell">{{ $nestedValue }}</td>
                            </tr>
                        @endforeach
                    @else
                        <tr>
                            <td class="key-cell">{{ $key }}</td>
                            <td class="value-cell">{{ $value / 100 }} EGP</td>
                        </tr>
                    @endif
                @endforeach
            </tbody>

        </table>
    </div>
    <div class="input-group">
        <form method="GET" action="{{ route('dayra.inventory.limit', ['uuid' => $uuid , 'amount' => 1400000]) }}">
            @csrf

            <div class="form-group">
                <label for="cart_name">Cart Name:</label>
                <input type="text" id="cart_name" name="cart_name" class="form-control" placeholder="Enter Cart Name" required>
            </div>

            <div class="form-group">
                <label for="invoice_number">Invoice Number:</label>
                <input type="text" id="invoice_number" name="invoice_number" class="form-control" placeholder="Enter Your Invoice Number" required>
            </div>

            <div class="form-group">
                <label for="amount">Order Amount In EGP:</label>
                <input type="number" id="amount" name="amount" class="form-control" placeholder="Enter Your Order Amount" required>
            </div>

            <input type="hidden" name="uuid" value="{{ $uuid }}">
            <input type="hidden" name="data[]" value="{{ $value  }}">
            <button type="submit" class="btn btn-primary" id="showOptionsBtn">Show financial Limit Avaliable</button>
        </form>
    </div>
</div>


@push('scripts')
<script>
    document.getElementById('limitForm').addEventListener('submit', function(event) {
        alert('Validation script is running'); // This should display when the form is submitted

        // Get min and max values from the HTML elements
        const minAmountElement = document.getElementById('min').textContent;
        const maxAmountElement = document.getElementById('max').textContent;

        // Extract numeric values from the text content of the elements
        const minAmount = parseFloat(minAmountElement.replace(/[^0-9.]/g, ''));
        const maxAmount = parseFloat(maxAmountElement.replace(/[^0-9.]/g, ''));

        // Get the amount input value
        const amount = parseFloat(document.getElementById('amount').value);

        alert(`Min: ${minAmount}, Max: ${maxAmount}, Entered: ${amount}`); // Display the extracted values

        // Validate the amount
        if (isNaN(amount) || amount < minAmount || amount > maxAmount) {
            event.preventDefault();  // Prevent form submission
            alert(`Please enter an amount between ${minAmount.toFixed(2)} and ${maxAmount.toFixed(2)} EGP.`);
        }
    });
</script>
@endpush
