@extends('Admin.index')

@section('content')
<div class="container-fluid mt-5">
    <div class="alert alert-success" role="alert">
        <strong>Loan Request Created Successfully.</strong> An action will be taken within 24 hours.
    </div>
</div>
@endsection
