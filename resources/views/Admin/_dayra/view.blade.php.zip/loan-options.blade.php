@extends('Admin.index')

@section('content')
<style>
html, body {
    height: 100%;
    margin: 0;
    padding: 0;
}

body {
    display: flex;
    flex-direction: column;
}

.container-fluid {
    flex: 1;
    width: 80%;
    max-width: 800px; /* Limit maximum width for better readability */
    margin: auto; /* Center align the form */
    padding: 50px;
}

.footer {
    background-color: #f8f9fa;
    padding: 10px 0;
    width: 100%;
    text-align: center;
}

.input-group {
    margin-bottom: 20px;
}

.input-group label {
    display: block;
    margin-bottom: 10px;
    font-size: 16px;
    font-weight: bold;
    color: #333; /* Adjust label color */
}

.input-group .custom-control {
    margin-bottom: 10px; /* Adjust spacing between options */
}

.input-group button {
    padding: 10px 20px;
    font-size: 16px;
    background-color: #3085d6;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.input-group button:hover {
    background-color: #1e4d8b;
}
</style>
<div class="container-fluid mt-5">
    <form id="loanOptionsForm" action="{{route('dayra.loan.request', $uuid)}}" method="POST">
        @csrf
        <div class="input-group">
            <label>Select Loan Option:</label>
            <!-- Custom checkboxes based on loan options -->
            @foreach ($data->data->payload->options as $key => $option)
                <div class="custom-control custom-radio">
                    <input type="radio" id="option{{$key}}" name="option_number" value="{{ $key }}" class="custom-control-input" required>
                    <label class="custom-control-label" for="option{{$key}}">
                        Due Date: {{ $option->due_date }},
                        Installment Amount: {{ $option->installment_amount/100 }} . 'EGP',
                        Number of Installments: {{ $option->installments_count }},
                        Total Due : {{ $option->total_due /100}} . 'EGP' ,
                        Interest : {{ $option->interest /100}} . 'EGP',
                        Principal : {{ $option->principal /100}} . 'EGP',
                        VaT : {{ $option->total_vat_amount / 100}} . 'EGP'

                    </label>
                </div>
            @endforeach
            
            <!-- Hidden input for UUID -->
            <input type="hidden" id="uuid" name="uuid" value="{{ $uuid }}">
            
            <!-- Hidden inputs for each option -->
            @foreach ($data->data->payload->options as $option)
                <input type="hidden" name="options[]" value='@json($option)'>
            @endforeach

            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </form>
</div>

@endsection
