@extends('Admin.index')

@section('content')
<style>
html, body {
    height: 100%;
    margin: 0;
    padding: 0;
}

body {
    display: flex;
    flex-direction: column;
}

.container-fluid {
    flex: 1;
    width: 80%;
    max-width: 800px; /* Limit maximum width for better readability */
    margin: auto; /* Center align the form */
    padding: 50px;
}

.footer {
    background-color: #f8f9fa;
    padding: 10px 0;
    width: 100%;
    text-align: center;
}

.key-cell {
    background-color: #3085d6;
    color: white;
    padding: 10px;
    font-weight: bold;
}

.value-cell {
    background-color: #f1f1f1;
    padding: 10px;
    color: #333;
}

.table-striped>tbody>tr:nth-of-type(odd) {
    background-color: #f9f9f9;
}

.table-striped>tbody>tr:nth-of-type(even) {
    background-color: #e9ecef;
}

.input-group {
    margin-top: 20px;
}

.input-group label {
    font-weight: bold;
    color: #333;
}

.btn-primary {
    padding: 10px 20px;
    font-size: 16px;
    background-color: #3085d6;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.btn-primary:hover {
    background-color: #1e4d8b;
}
</style>

<div class="container-fluid mt-5">
    <div class="table-responsive">
        <table class="table table-striped">
            <tbody id="userData">
                @foreach ($data as $key => $value)
                    @if (is_array($value))
                        @foreach ($value as $nestedKey => $nestedValue)
                            <tr>
                                <td class="key-cell">{{ $nestedKey }}</td>
                                <td class="value-cell">{{ $nestedValue }}</td>
                            </tr>
                        @endforeach
                    @else
                        <tr>
                            <td class="key-cell">{{ $key }}</td>
                            <td class="value-cell">{{ $value / 100 }} EGP</td>
                        </tr>
                    @endif
                @endforeach
            </tbody>
        </table>
    </div>

    <div class="input-group mt-4">
        <form method="GET" action="{{ route('dayra.loan.options', ['uuid' => $uuid]) }}">
            @csrf

            <div class="form-group">
                <label for="amount">Order Amount In EGP:</label>
                <input type="number" id="amount" name="amount" class="form-control" placeholder="Enter Your Order Amount" required>
            </div>

            <input type="hidden" name="uuid" value="{{ $uuid }}">
            <input type="hidden" name="data[]" value="{{ json_encode($data) }}">
            <button type="submit" class="btn btn-primary" id="showOptionsBtn">Show Avaliable Loans Options</button>
        </form>
    </div>
</div>

@endsection

@push('scripts')
<script>
    document.getElementById('showOptionsBtn').addEventListener('click', function(event) {
        const amount = document.getElementById('amount').value;
        if (!amount) {
            event.preventDefault();
            alert('Please enter an amount.');
            return;
        }
    });
</script>
@endpush