<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class OrderPlacedNotifcationMail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public $order;

    public $subject;

    public function __construct($order)
    {
        $this->order = $order;

        $this->subject = 'New order #' . $this->order->id . ' has been placed on tawredaat.com ! ';
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $subject = 'New order #' . $this->order->id . ' has been placed on tawredaat.com ! ';
        return $this->from('info@tawredaat.com', 'tawredaat.com')->markdown('User.mails.OrderPlacedNotifcation')->subject($subject);
    }
}
