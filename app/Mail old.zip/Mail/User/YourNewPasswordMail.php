<?php

namespace App\Mail\User;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class YourNewPasswordMail extends Mailable
{
    use Queueable, SerializesModels;

    public $new_password;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($new_password)
    {
        $this->new_password = $new_password;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $subject = 'Your new password for ' . config('global.used_website');

        return $this->from(config('global.used_sent_from_email'),
            config('global.used_website'))
            ->markdown('User.mails.your_new_password')
            ->subject($subject);
    }
}
